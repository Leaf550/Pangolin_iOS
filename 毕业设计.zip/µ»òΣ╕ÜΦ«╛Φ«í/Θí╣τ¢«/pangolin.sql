-- MySQL dump 10.13  Distrib 8.0.27, for macos11 (x86_64)
--
-- Host: localhost    Database: pangolin
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bbsComments`
--

DROP TABLE IF EXISTS `bbsComments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bbsComments` (
  `commentId` varchar(32) NOT NULL,
  `postId` varchar(32) NOT NULL,
  `sourceUserId` varchar(32) NOT NULL,
  `targetUserId` varchar(32) DEFAULT NULL,
  `createTime` bigint NOT NULL,
  `content` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`commentId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbsComments`
--

LOCK TABLES `bbsComments` WRITE;
/*!40000 ALTER TABLE `bbsComments` DISABLE KEYS */;
INSERT INTO `bbsComments` VALUES ('15f7f8332a7146d7b52925fce0914864','91e56ead984e43669786048096a8524a','e5d493ab44f94e799e411d633706d00a','a7c21dce1d684e698bbf666e4fd4c198',1653238840,'鸭！捕捉！！'),('1675378c2dde44488d3f79e45964d802','a9902a2c5bea47669085b97ff7780d73','a220e27bd3b64dcfa4f5601562218b66',NULL,1653238990,'我也挺喜欢Swift的，相比OC现代化了不少～～'),('5270f4503f144aeb898327179cf4af15','a9902a2c5bea47669085b97ff7780d73','a7c21dce1d684e698bbf666e4fd4c198','a220e27bd3b64dcfa4f5601562218b66',1653239053,'是的，Swift简洁、优雅、安全、高效，是一门优秀的语言'),('8e543bc1f37b49319ac089bc8addc409','a9902a2c5bea47669085b97ff7780d73','e5d493ab44f94e799e411d633706d00a',NULL,1653238943,'嗯，确实不错'),('acbd3049a3a9450e982539767abba42b','91e56ead984e43669786048096a8524a','a7c21dce1d684e698bbf666e4fd4c198',NULL,1653235496,'感谢代码贡献！');
/*!40000 ALTER TABLE `bbsComments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbsPosts`
--

DROP TABLE IF EXISTS `bbsPosts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bbsPosts` (
  `postId` varchar(32) NOT NULL,
  `authorId` varchar(32) NOT NULL,
  `createTime` bigint NOT NULL,
  `content` varchar(100) DEFAULT NULL,
  `taskId` varchar(32) NOT NULL,
  `praiseCount` int NOT NULL,
  PRIMARY KEY (`postId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbsPosts`
--

LOCK TABLES `bbsPosts` WRITE;
/*!40000 ALTER TABLE `bbsPosts` DISABLE KEYS */;
INSERT INTO `bbsPosts` VALUES ('91e56ead984e43669786048096a8524a','a220e27bd3b64dcfa4f5601562218b66',1651381432,'哈哈，给Pangolin提的pull request被合并了，给开发者打电话～','677f03da21a64dc29a7294c5451e35c6',0),('a9902a2c5bea47669085b97ff7780d73','a7c21dce1d684e698bbf666e4fd4c198',1651390257,'一直听说Swift是一门不错的语言，终于有机会接触了一下，针不戳！','fbce34dd7f624f10839aefb66e81fb8f',1);
/*!40000 ALTER TABLE `bbsPosts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `images`
--

DROP TABLE IF EXISTS `images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `images` (
  `uid` varchar(32) NOT NULL,
  `url` varchar(100) NOT NULL,
  `postId` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`url`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `images`
--

LOCK TABLES `images` WRITE;
/*!40000 ALTER TABLE `images` DISABLE KEYS */;
INSERT INTO `images` VALUES ('a7c21dce1d684e698bbf666e4fd4c198','http://127.0.0.1:8080/images/bbs/72ab2b96623a4d3bb07011419a85f1f7.jpeg','a9902a2c5bea47669085b97ff7780d73');
/*!40000 ALTER TABLE `images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `praise`
--

DROP TABLE IF EXISTS `praise`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `praise` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uid` varchar(32) NOT NULL,
  `postId` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `praise`
--

LOCK TABLES `praise` WRITE;
/*!40000 ALTER TABLE `praise` DISABLE KEYS */;
INSERT INTO `praise` VALUES (6,'a220e27bd3b64dcfa4f5601562218b66','a9902a2c5bea47669085b97ff7780d73');
/*!40000 ALTER TABLE `praise` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taskLists`
--

DROP TABLE IF EXISTS `taskLists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `taskLists` (
  `listId` varchar(32) NOT NULL,
  `uid` varchar(32) NOT NULL,
  `listType` tinyint NOT NULL,
  `listName` varchar(10) NOT NULL,
  `listColor` tinyint NOT NULL,
  `imageName` varchar(10) NOT NULL,
  `completedCount` int DEFAULT NULL,
  `createTime` bigint NOT NULL,
  `sortedBy` tinyint NOT NULL,
  PRIMARY KEY (`listId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taskLists`
--

LOCK TABLES `taskLists` WRITE;
/*!40000 ALTER TABLE `taskLists` DISABLE KEYS */;
INSERT INTO `taskLists` VALUES ('26295bb34bfb401499eb98218ad0ea1a','a7c21dce1d684e698bbf666e4fd4c198',4,'行程',3,'18',0,1651307052,0),('4896d95896d64099b47003b355189ab2','a7c21dce1d684e698bbf666e4fd4c198',4,'学习',0,'3',0,1651306801,0),('52ef199ef0ae44c0a9765030d65e7c09','a7c21dce1d684e698bbf666e4fd4c198',4,'健身',1,'16',0,1651306957,0),('78dcf3b5dc2e43d8b0f93e3e586bfc18','a7c21dce1d684e698bbf666e4fd4c198',4,'买东西',4,'6',0,1651307383,0),('c0c34c0766e24802bc025fc0ea39eee6','a7c21dce1d684e698bbf666e4fd4c198',4,'吃药',5,'21',0,1651307430,0),('c39c00e0a0bb4cdeb2134bbae4904416','a7c21dce1d684e698bbf666e4fd4c198',4,'存钱',2,'22',0,1651307011,0),('cbbdfe63f95344c7badc7ce3e4cc8a3b','a220e27bd3b64dcfa4f5601562218b66',4,'测试',0,'0',0,1651390390,0);
/*!40000 ALTER TABLE `taskLists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tasks`
--

DROP TABLE IF EXISTS `tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tasks` (
  `uid` varchar(32) NOT NULL,
  `taskId` varchar(32) NOT NULL,
  `title` varchar(20) NOT NULL,
  `comment` varchar(40) DEFAULT NULL,
  `date` bigint DEFAULT NULL,
  `time` bigint DEFAULT NULL,
  `isImportant` tinyint(1) NOT NULL,
  `isCompleted` tinyint(1) NOT NULL,
  `createTime` bigint NOT NULL,
  `priority` tinyint NOT NULL,
  `listId` varchar(32) NOT NULL,
  `shared` tinyint(1) NOT NULL DEFAULT '0',
  `completeTime` bigint DEFAULT NULL,
  PRIMARY KEY (`taskId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tasks`
--

LOCK TABLES `tasks` WRITE;
/*!40000 ALTER TABLE `tasks` DISABLE KEYS */;
INSERT INTO `tasks` VALUES ('a7c21dce1d684e698bbf666e4fd4c198','289d0d9b5c8743cabb2891225e8bf93a','毕业了，出去玩一玩','但是还没想好去哪里…',1655222400,NULL,0,0,1651308462,0,'26295bb34bfb401499eb98218ad0ea1a',0,0),('a7c21dce1d684e698bbf666e4fd4c198','3478f688adcb41069dc8ea4904cb018c','定个小目标，6月之前存好2000块',NULL,1653926400,NULL,1,0,1651308208,0,'c39c00e0a0bb4cdeb2134bbae4904416',0,0),('a220e27bd3b64dcfa4f5601562218b66','677f03da21a64dc29a7294c5451e35c6','为Pangolin贡献一次代码',NULL,1651334400,NULL,0,1,1651390432,0,'cbbdfe63f95344c7badc7ce3e4cc8a3b',1,1651390495),('a7c21dce1d684e698bbf666e4fd4c198','708a2af6d4e84b9cbdad593f55fbc21c','写一个iOS Demo',NULL,1652803200,NULL,0,0,1651307901,0,'4896d95896d64099b47003b355189ab2',0,0),('a7c21dce1d684e698bbf666e4fd4c198','74e14980f9e2450bbdb07044e82306ab','去超市买点零食',NULL,1651420800,NULL,1,0,1651308653,0,'78dcf3b5dc2e43d8b0f93e3e586bfc18',0,0),('a7c21dce1d684e698bbf666e4fd4c198','77ee9598eba749c8acf0e192e3565c91','试着发送一个网络请求',NULL,1653148800,NULL,0,0,1651307954,0,'4896d95896d64099b47003b355189ab2',0,0),('a7c21dce1d684e698bbf666e4fd4c198','bb3cb55e8a7e480ab14773eebcc487c3','了解UIKit框架用法',NULL,1652544000,NULL,0,1,1651307850,0,'4896d95896d64099b47003b355189ab2',0,1651308722),('a7c21dce1d684e698bbf666e4fd4c198','cbc15a6671a84906a24c37e336405472','去健身房撸铁',NULL,1653321600,1653393600,0,0,1653384075,0,'52ef199ef0ae44c0a9765030d65e7c09',0,0),('a7c21dce1d684e698bbf666e4fd4c198','cdc3353139c144ddae96d20f000520c3','学习AutoLayout的用法','使用SnapKit布局',1652976000,NULL,0,0,1651307933,0,'4896d95896d64099b47003b355189ab2',0,0),('a7c21dce1d684e698bbf666e4fd4c198','eb4f4ddd613d4a8292b00a9f487ead8d','学习MVVM怎么写',NULL,1653408000,NULL,1,0,1651308003,0,'4896d95896d64099b47003b355189ab2',0,0),('a7c21dce1d684e698bbf666e4fd4c198','f372ea2d29c64bb89cab3512a22a5b3f','看看iOS runtime是如何运行的',NULL,1653840000,NULL,1,0,1651308026,0,'4896d95896d64099b47003b355189ab2',0,0),('a7c21dce1d684e698bbf666e4fd4c198','fbce34dd7f624f10839aefb66e81fb8f','学写Swift代码',NULL,1652112000,NULL,1,1,1651307805,0,'4896d95896d64099b47003b355189ab2',1,1651308667);
/*!40000 ALTER TABLE `tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `uid` varchar(32) NOT NULL,
  `username` varchar(12) NOT NULL,
  `secPassword` varchar(32) NOT NULL,
  `salt` varchar(128) NOT NULL,
  `level` tinyint NOT NULL,
  `experience` int NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('15bc7992049e414d8cf4d2233204355b','Pangolin1','f7a7f79709edd84fcaa3b55b5829f5b8','94edb5a44913449c980602922b5ca9cce5f4fbbb6bfd606c4c61a763e8bc66bfa9e5cc07caeb9a2ea551b87a896b97300d1f9ecd5c2d0c3371ec5e75d58c3c3e',0,0),('17bca6dbd53e44b981c700f87cfc6441','Pangolin2','fd7b273ced091e607888c0233ed8f032','f3f43fd9731a5b461930ea123b217d1ebebcfc56d166ffec2f5ed28322e9b73d0c7fdbf9bfaf4c55f5286d22c847e89b661c42232f07be4e086b5189ad7b3394',0,0),('a220e27bd3b64dcfa4f5601562218b66','YuHeng','c9294cad80896b4888d9a4b532a716b8','ceeea0e1995989988b4f37cb9d169e714d16efbf4dfd8f485535f430d748a16472569669fc1b3b70db75139ef672991eb95225f70b7bedbb14aeb98ed31b03be',0,0),('a7c21dce1d684e698bbf666e4fd4c198','Pangolin','53c57afc27b0045f0ff8c53109722338','619cee2b925c0d170758fccb7b1f77dc1617823c7b6f920a535bd35d7b6f8b634af5c6c9b1ba6d53e6a2ff34d541b38ea2c06f2ab03a6feac27183c4dec8178e',0,0),('e5d493ab44f94e799e411d633706d00a','Helong','f02df96918d6030d1d7b897b6173d0d6','86e1f7e3ad0cc60cf3e7a10c27450cded7cc98dfc697bb0f90c01d7125435b43811ab305c53f4c1738da0b109bb6062f1d0ef66c0396af68618ed4dee60d3bf2',0,0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-06-11 11:45:24
