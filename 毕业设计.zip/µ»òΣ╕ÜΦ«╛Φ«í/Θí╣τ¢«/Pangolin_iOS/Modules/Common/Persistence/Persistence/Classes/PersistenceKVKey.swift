//
//  PersistenceKVKey.swift
//  Persistence
//
//  Created by 方昱恒 on 2022/3/19.
//

import UIKit

class PersistenceKVKey {
    static var userKVKey        = "userKVKey"
    static var tokenKVKey       = "tokenKVKey"
    static var homeModelKVKey   = "homeModelKVKey"
}
