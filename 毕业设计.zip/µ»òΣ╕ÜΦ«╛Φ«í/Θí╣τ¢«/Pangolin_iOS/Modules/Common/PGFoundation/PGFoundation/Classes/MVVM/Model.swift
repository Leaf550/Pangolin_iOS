//
//  Model.swift
//  RxTest
//
//  Created by 方昱恒 on 2021/12/23.
//


// Model 没有任何内容，用来声明类型、提高可读性
public protocol Model { }
