package com.yuheng.pangolin.constant;

public class RequestParameterConstant {
    // user
    public static final String USERNAME = "username";
    public static final String PASSWORD = "password";
}
