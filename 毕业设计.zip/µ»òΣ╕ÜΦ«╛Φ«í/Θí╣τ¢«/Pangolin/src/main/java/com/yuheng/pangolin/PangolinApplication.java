package com.yuheng.pangolin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PangolinApplication {

    public static void main(String[] args) {
        SpringApplication.run(PangolinApplication.class, args);
    }

}
