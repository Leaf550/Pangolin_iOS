package com.yuheng.pangolin.service.test;

import com.yuheng.pangolin.model.TestModel;

import java.util.List;

public interface TestService {
    TestModel getTestDataById(int id);
}
