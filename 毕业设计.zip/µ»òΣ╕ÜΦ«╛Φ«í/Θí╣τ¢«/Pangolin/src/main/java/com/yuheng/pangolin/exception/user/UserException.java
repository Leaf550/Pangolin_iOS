package com.yuheng.pangolin.exception.user;

import com.yuheng.pangolin.exception.BaseException;

public class UserException extends Exception {
    public UserException(String message) {
        super(message);
    }
}
