package com.yuheng.pangolin.config;

import lombok.NoArgsConstructor;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

public class TokenConfigTest {

}
