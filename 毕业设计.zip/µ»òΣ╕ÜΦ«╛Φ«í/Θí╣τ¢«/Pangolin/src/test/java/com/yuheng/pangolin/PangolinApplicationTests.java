package com.yuheng.pangolin;

import com.yuheng.pangolin.config.TokenConfig;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.stereotype.Component;

@SpringBootTest
class PangolinApplicationTests {

    void contextLoads() {
    }

}
